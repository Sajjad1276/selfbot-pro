
import json
import os
import logging
from datetime import datetime
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)

TOKEN = os.getenv("BOT_TOKEN", "PASTE_YOUR_TOKEN_HERE")
ADMIN_ID = 123456789
DB_FILE = "db.json"

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

def load_db():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "w") as f:
            json.dump({"users": {}, "posts": []}, f)
    with open(DB_FILE, "r") as f:
        return json.load(f)

def save_db(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=2)

async def start
    db = load_db()
    if str(update.effective_user.id) in db['users'] and db['users'][str(update.effective_user.id)].get('banned'):
        await update.message.reply_text('🚫 شما توسط مدیریت مسدود شده‌اید.')
        return(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    uid = str(update.effective_user.id)
    ref = context.args[0].replace("ref_", "") if context.args else None
    if uid not in db["users"]:
        db["users"][uid] = {
            "coins": 0,
            "submitted": False,
            "views": [],
            "last_submit": "",
            "ref": ref if ref and ref != uid else None,
        }
        if ref and ref in db["users"]:
            db["users"][ref]["coins"] += 5
            await context.bot.send_message(chat_id=int(ref), text="🎉 یکی با لینک دعوتت وارد شد و تو ۵ سکه گرفتی!")
    save_db(db)
    await update.message.reply_text(
        """👋 <b>خوش اومدی!</b>

با دیدن پست‌ها سکه بگیر 💰 و پست خودتو تبلیغ کن 📢!

📝 <b>دستورات:</b>
/submit - ارسال پست برای نمایش
/view - دریافت پست‌های دیگران
/status - وضعیت حساب"""
        "/submit - ارسال پست\n"
        "/view - دیدن پست‌ها\n"
        "/status - بررسی وضعیت"
    )

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    uid = str(update.effective_user.id)
    user = db["users"].get(uid, {})
    coins = user.get("coins", 0)
    total_posts = sum(1 for p in db["posts"] if p["user"] == uid)
    invite = f"https://t.me/YOUR_BOT_USERNAME?start=ref_{uid}"
    await update.message.reply_text(f"""📊 <b>وضعیت حساب شما</b>:

💰 سکه: <b>{coins}</b>
📝 پست‌های ارسال‌شده: <b>{total_posts}</b>
🔗 لینک دعوت: <code>{invite}</code>""", parse_mode="HTML")

async def submit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    uid = str(update.effective_user.id)
    user = db["users"].get(uid)
    today = datetime.now().strftime("%Y-%m-%d")
    if user["coins"] < 5:
        await update.message.reply_text("🚫 <b>سکه کافی نداری!</b>\nباید حداقل ۵ سکه داشته باشی.", parse_mode="HTML")
        return ConversationHandler.END
    if user["last_submit"] == today:
        await update.message.reply_text("⏳ امروز قبلاً یک پست ثبت کردی.")
        return ConversationHandler.END
    await update.message.reply_text("لطفاً پستت رو بفرست (متن، عکس یا ویدیو):")
    return 1

async def receive_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    uid = str(update.effective_user.id)
    post = {
        "user": uid,
        "text": update.message.caption or update.message.text or "",
        "photo": update.message.photo[-1].file_id if update.message.photo else None,
        "video": update.message.video.file_id if update.message.video else None,
        "views": 0,
    }
    db["posts"].append(post)
    db["users"][uid]["coins"] -= 5
    db["users"][uid]["last_submit"] = datetime.now().strftime("%Y-%m-%d")
    save_db(db)
    await update.message.reply_text("✅ <b>پست با موفقیت ثبت شد!</b>\nبا دیدن پست‌های دیگران دوباره سکه جمع کن 💰", parse_mode="HTML")
    return ConversationHandler.END

async def view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    uid = str(update.effective_user.id)
    user = db["users"].get(uid)
    for post in db["posts"]:
        if post["user"] == uid or post in user["views"]:
            continue
        user["views"].append(post)
        user["coins"] += 1
        post["views"] += 1
        if post["photo"]:
            await update.message.reply_photo(post["photo"], caption=post["text"])
        elif post["video"]:
            await update.message.reply_video(post["video"], caption=post["text"])
        else:
            await update.message.reply_text(post["text"])
        save_db(db)
        return
    await update.message.reply_text("🎉 <b>تبریک!</b>\nشما همه پست‌های موجود رو دیدی. منتظر پست‌های جدید بمون!", parse_mode="HTML")

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    db = load_db()
    await update.message.reply_text(f"👑 پنل مدیریت:\nکاربران: {len(db['users'])}\nپست‌ها: {len(db['posts'])}")


async def addcoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if len(context.args) != 2:
        await update.message.reply_text("❗ استفاده صحیح: /addcoins user_id amount")
        return
    uid, amount = context.args
    db = load_db()
    if uid not in db["users"]:
        await update.message.reply_text("❌ کاربر پیدا نشد.")
        return
    db["users"][uid]["coins"] += int(amount)
    save_db(db)
    await update.message.reply_text(f"✅ {amount} سکه به کاربر {uid} اضافه شد.")

async def setcoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if len(context.args) != 2:
        await update.message.reply_text("❗ استفاده صحیح: /setcoins user_id amount")
        return
    uid, amount = context.args
    db = load_db()
    if uid not in db["users"]:
        await update.message.reply_text("❌ کاربر پیدا نشد.")
        return
    db["users"][uid]["coins"] = int(amount)
    save_db(db)
    await update.message.reply_text(f"✅ تعداد سکه کاربر {uid} به {amount} تنظیم شد.")



async def ban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not context.args:
        await update.message.reply_text("❗ استفاده صحیح: /ban user_id")
        return
    uid = context.args[0]
    db = load_db()
    if uid not in db["users"]:
        await update.message.reply_text("❌ کاربر پیدا نشد.")
        return
    db["users"][uid]["banned"] = True
    save_db(db)
    await update.message.reply_text(f"🚫 کاربر {uid} بن شد.")

async def unban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not context.args:
        await update.message.reply_text("❗ استفاده صحیح: /unban user_id")
        return
    uid = context.args[0]
    db = load_db()
    if uid not in db["users"]:
        await update.message.reply_text("❌ کاربر پیدا نشد.")
        return
    db["users"][uid]["banned"] = False
    save_db(db)
    await update.message.reply_text(f"✅ کاربر {uid} آزاد شد.")

async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    msg = " ".join(context.args)
    if not msg:
        await update.message.reply_text("❗ استفاده صحیح: /broadcast پیام")
        return
    db = load_db()
    count = 0
    for uid in db["users"]:
        try:
            await context.bot.send_message(chat_id=int(uid), text=msg)
            count += 1
        except:
            continue
    await update.message.reply_text(f"📢 پیام به {count} کاربر ارسال شد.")

async def delposts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not context.args:
        await update.message.reply_text("❗ استفاده صحیح: /delposts user_id")
        return
    uid = context.args[0]
    db = load_db()
    before = len(db["posts"])
    db["posts"] = [p for p in db["posts"] if p["user"] != uid]
    after = len(db["posts"])
    save_db(db)
    await update.message.reply_text(f"🗑 {before - after} پست از کاربر {uid} حذف شد.")


if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    conv = ConversationHandler(
        entry_points=[CommandHandler("submit", submit)],
        states={1: [MessageHandler(filters.TEXT | filters.PHOTO | filters.VIDEO, receive_post)]},
        fallbacks=[],
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("view", view))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(conv)
    app.add_handler(CommandHandler("addcoins", addcoins))
    app.add_handler(CommandHandler("setcoins", setcoins))
    app.add_handler(CommandHandler("ban", ban))
    app.add_handler(CommandHandler("unban", unban))
    app.add_handler(CommandHandler("broadcast", broadcast))
    app.add_handler(CommandHandler("delposts", delposts))
    print("🤖 Bot is running...")
    app.run_polling()
